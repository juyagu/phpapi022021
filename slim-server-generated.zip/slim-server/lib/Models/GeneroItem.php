<?php
/*
 * GeneroItem
 */
namespace \Models;

/*
 * GeneroItem
 */
class GeneroItem {
    /* @var Number $idGenero  */
    private $idGenero;
/* @var string $descripcion  */
    private $descripcion;
}
