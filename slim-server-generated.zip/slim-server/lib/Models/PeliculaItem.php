<?php
/*
 * PeliculaItem
 */
namespace \Models;

/*
 * PeliculaItem
 */
class PeliculaItem {
    /* @var Number $id  */
    private $id;
/* @var string $titulo  */
    private $titulo;
/* @var string $genero  */
    private $genero;
/* @var string $director  */
    private $director;
/* @var string $foto  */
    private $foto;
}
