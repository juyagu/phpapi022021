<?php
/*
 * PeliculaModificar
 */
namespace \Models;

/*
 * PeliculaModificar
 */
class PeliculaModificar {
    /* @var string $titulo  */
    private $titulo;
/* @var string $genero  */
    private $genero;
/* @var string $director  */
    private $director;
}
