<?php 

$coleccionLoca = [432,342,"hola"];

$coleccionLoca1 = 432;
$coleccionLoca2 = 342;
$coleccionLoca3 = "hola";

echo $coleccionLoca1 . PHP_EOL;
echo $coleccionLoca2 . PHP_EOL;
echo $coleccionLoca3 . PHP_EOL;


echo $coleccionLoca[0] . PHP_EOL;
echo $coleccionLoca[1] . PHP_EOL;
echo $coleccionLoca[2] . PHP_EOL;