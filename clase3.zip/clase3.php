<?php 
 
 class Can {
    public function saludar(){
        echo 'El can te muestra los colmillas';
    }
 }

 class Perro extends Can { 
    public function saludar(){
        echo 'El perro te mueve la cola';
    }
 }

 
