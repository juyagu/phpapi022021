<?php 

class Estudiante{
    private $nombre;
    private $legajo;
    private $materias;

    public function setNombre($n){
        $this->nombre = $n;
    }

    public function getNombre(){
        return $this->nombre;
    }

    public function setLegajo($l){
        $this->legajo = $l;
    }

    public function getLegajo(){
        return $this->legajo;
    }

    public function setMaterias($m){
        $this->materias = $m;
    }

    public function getMaterias(){
        return $this->materias;
    }

    public function reporteEstudiante(){
        echo '
            <h1>Reporte del estudiante </h1>
            <ul>
                <li>Nombre: ' . $this->nombre . '</li>
                <li>Legajo: ' . $this->legajo . '</li>
                <li>Materia 1: ' . $this->materias[0]->getNombre() . '</li>
                <li>Programa de la materia 1: ' . $this->materias[0]->getPrograma() . '</li>
                <li>Materia 2: ' . $this->materias[1]->getNombre() . '</li>
                <li>Programa de la materia 1: ' . $this->materias[1]->getPrograma() . '</li>
                <li>Materia 3: ' . $this->materias[2]->getNombre() . '</li>
                <li>Programa de la materia 3: ' . $this->materias[2]->getPrograma() . '</li>
            </ul>';
    }
}


class Materia {
    private $nombre;
    private $programa;


    public function setNombre($n){
        $this->nombre = $n;
    }

    public function getNombre(){
        return $this->nombre;
    }

    public function setPrograma($p){
        $this->programa = $p;
    }

    public function getPrograma(){
        return $this->programa;
    }
}


$m1 = new Materia();
$m1->setNombre('Desarrollador Javascript Frontend');
$m1->setPrograma('Programa de JS');

$m2 = new Materia();
$m2->setNombre('Introducción al Paradigma de Objetos');
$m2->setPrograma('Programa de OOP');

$m3 = new Materia();
$m3->setNombre('Introducción a MongoDB');
$m3->setPrograma('Programa de Mongo');

$materias = array();
$materias[0] = $m1;
$materias[1] = $m2;
$materias[2] = $m3;

$e1 = new Estudiante();
$e1->setNombre('Ana Perez');
$e1->setLegajo(1234);
$e1->setMaterias($materias);


$e1->reporteEstudiante();
